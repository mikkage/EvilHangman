#include <iostream>
#include "hangman.h"
using namespace std;

int main()
{
	hangman h;
	h.playGame();	
	cin.get();
	return 0;
}
